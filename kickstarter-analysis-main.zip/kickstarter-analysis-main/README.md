# kickstarter-analysis
Module exercise: performing analysis on kickstarter data to uncover trends
